<?php
define('IN_MOBILE', true);
require '../../source/bootstrap.inc.php';
message('支付失败, 请稍后重试.');
