<?php
/**
 * 版本号
 *
 * [WeEngine System] Copyright (c) 2013 WE7.CC
 */

defined('IN_IA') or exit('Access Denied');

define('IMS_FAMILY', 'v');
define('IMS_VERSION', '0.7');
define('IMS_RELEASE_DATE', '201606010000');