<?php 
return $this->respText('没有找到结果, 要不换个词试试?');
